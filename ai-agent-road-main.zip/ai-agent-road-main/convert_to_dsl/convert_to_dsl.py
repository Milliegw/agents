"""
This script analyzes Python codebases to generate a Structurizr DSL representation of its structure.

The script uses the Abstract Syntax Tree (AST) module to parse Python files and extract information about:
- Classes and their methods
- Standalone functions

The extracted components are then converted into a Structurizr DSL format, which can be used to visualize the architecture of the codebase.

Key functionalities:
1. `C4DSLGenerator`:
   - A class that traverses the AST to collect classes, methods, and functions.
   - Generates Structurizr DSL from the collected components.

2. `parse_python_code`:
   - Parses a single Python file and generates Structurizr DSL.

3. `parse_codebase`:
   - Recursively parses all Python files in a directory and generates a combined Structurizr DSL.

4. Command-line usage:
   - The script accepts a file or directory path as input and generates a `c4_model.dsl` file in the current working directory.

Usage:
    python convert_to_dsl.py <path_to_python_file_or_directory>

@author: lwowen
"""

import ast
import sys
import os

class C4DSLGenerator(ast.NodeVisitor):
    """
    A class to generate Structurizr DSL from Python code by analyzing classes and functions.

    Attributes:
        components (dict): A dictionary containing classes and their methods, and standalone functions.
    """

    def __init__(self):
        """
        Initializes the C4DSLGenerator with empty components for classes and functions.
        """
        self.components = {"classes": {}, "functions": set()}  # Use set for functions to avoid duplicates

    def visit_ClassDef(self, node):
        """
        Visits a class definition node in the AST and extracts its methods.

        Args:
            node (ast.ClassDef): The class definition node.
        """
        # Capture class definitions as components
        methods = [n.name for n in node.body if isinstance(n, ast.FunctionDef)]
        if node.name not in self.components["classes"]:
            self.components["classes"][node.name] = set(methods)  # Use set for methods to avoid duplicates
        else:
            self.components["classes"][node.name].update(methods)
        self.generic_visit(node)

    def visit_FunctionDef(self, node):
        """
        Visits a function definition node in the AST and adds it to the functions set.

        Args:
            node (ast.FunctionDef): The function definition node.
        """
        # Capture standalone functions
        self.components["functions"].add(node.name)  # Add to set to avoid duplicates
        self.generic_visit(node)

    def generate_structurizr_dsl(self):
        """
        Generates Structurizr DSL from the collected components.

        Returns:
            str: The generated Structurizr DSL as a string.
        """
        # Convert components into Structurizr DSL format
        dsl_lines = ["workspace {", "    model {"]

        # Ensure the software system is always defined
        dsl_lines.append("        softwareSystem \"Python Codebase\" {")

        if not self.components["classes"] and not self.components["functions"]:
            # Add a placeholder if no components are found
            dsl_lines.append("            container \"Placeholder\" {")
            dsl_lines.append("                component \"No components found\"")
            dsl_lines.append("            }")
        else:
            for class_name, methods in self.components["classes"].items():
                dsl_lines.append(f"            container \"{class_name}\" {{")
                for method in sorted(methods):  # Sort for consistent output
                    dsl_lines.append(f"                component \"{method}\"")
                dsl_lines.append("            }")

            if self.components["functions"]:
                dsl_lines.append("            container \"Functions\" {")
                for function in sorted(self.components["functions"]):  # Sort for consistent output
                    dsl_lines.append(f"                component \"{function}\"")
                dsl_lines.append("            }")

        dsl_lines.append("        }")  # Close softwareSystem block
        dsl_lines.append("    }")      # Close model block
        dsl_lines.append("    views {")
        dsl_lines.append("        systemContext \"Python Codebase\" {")  # Correct reference
        dsl_lines.append("            include *")
        dsl_lines.append("            autolayout lr")
        dsl_lines.append("        }")
        dsl_lines.append("        theme default")
        dsl_lines.append("    }")
        dsl_lines.append("}")

        # Log the generated DSL for debugging
        print("Generated Structurizr DSL:")
        print("\n".join(dsl_lines))

        return "\n".join(dsl_lines)

def parse_python_code(file_path):
    """
    Parses a single Python file and generates Structurizr DSL.

    Args:
        file_path (str): The path to the Python file.

    Returns:
        str: The generated Structurizr DSL or an error message if parsing fails.
    """
    try:
        with open(file_path, "r") as file:
            tree = ast.parse(file.read())
        generator = C4DSLGenerator()
        generator.visit(tree)
        return generator.generate_structurizr_dsl()
    except Exception as e:
        print(f"Error parsing {file_path}: {e}")
        return ""

def parse_codebase(directory_path):
    """
    Recursively parses all Python files in a directory and generates Structurizr DSL.

    Args:
        directory_path (str): The path to the directory containing Python files.

    Returns:
        str: The generated Structurizr DSL for the entire codebase.
    """
    # Recursively parse all .py files in the directory
    combined_components = {"classes": {}, "functions": set()}  # Use set for functions to avoid duplicates
    for root, _, files in os.walk(directory_path):
        for file in files:
            if file.endswith(".py"):
                file_path = os.path.join(root, file)
                try:
                    with open(file_path, "r") as f:
                        tree = ast.parse(f.read())
                    generator = C4DSLGenerator()
                    generator.visit(tree)
                    # Merge components
                    for class_name, methods in generator.components["classes"].items():
                        if class_name not in combined_components["classes"]:
                            combined_components["classes"][class_name] = set(methods)
                        else:
                            combined_components["classes"][class_name].update(methods)
                    combined_components["functions"].update(generator.components["functions"])
                except Exception as e:
                    print(f"Error parsing {file_path}: {e}")

    # Ensure the software system is always defined, even if no components are found
    if not combined_components["classes"] and not combined_components["functions"]:
        combined_components["classes"]["Placeholder"] = {"No components found"}

    # Generate a single Structurizr DSL
    generator = C4DSLGenerator()
    generator.components = combined_components
    return generator.generate_structurizr_dsl()

if __name__ == "__main__":
    """
    Entry point for the script. Parses a Python file or directory and generates Structurizr DSL.
    """
    if len(sys.argv) != 2:
        print("Usage: python dsl.py <path_to_python_file_or_directory>")
        sys.exit(1)

    path = sys.argv[1]
    if os.path.isfile(path):
        dsl_output = parse_python_code(path)
    elif os.path.isdir(path):
        dsl_output = parse_codebase(path)
    else:
        print("Invalid path. Provide a valid file or directory.")
        sys.exit(1)

    # Log the final DSL output for debugging
    print("Final Structurizr DSL Output:")
    print(dsl_output)

    output_file = os.path.join(os.getcwd(), "c4_model.dsl")  # Save as Structurizr DSL
    with open(output_file, "w") as f:
        f.write(dsl_output)

    print(f"Structurizr DSL saved to {output_file}")